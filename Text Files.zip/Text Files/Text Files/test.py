import heapq
import os


# Node class for constructing the Huffman tree
class Node:
    def __init__(self, freq, char=None):
        self.freq = freq
        self.char = char
        self.left = None
        self.right = None

    def __lt__(self, other):
        return self.freq < other.freq


# Function to generate Huffman codes for each character
def generate_codes(root, current_code, codes):
    if not root:
        return

    if root.char:
        codes[root.char] = current_code
        return

    generate_codes(root.left, current_code + "0", codes)
    generate_codes(root.right, current_code + "1", codes)


# Function to encode the input text using Huffman coding
def huffman_encoding(text):
    # Count the frequency of each character
    frequency = {}
    for char in text:
        if char in frequency:
            frequency[char] += 1
        else:
            frequency[char] = 1

    # Create a priority queue for the nodes
    priority_queue = [Node(freq, char) for char, freq in frequency.items()]
    heapq.heapify(priority_queue)

    # Build the Huffman tree
    while len(priority_queue) > 1:
        node1 = heapq.heappop(priority_queue)
        node2 = heapq.heappop(priority_queue)
        merged = Node(node1.freq + node2.freq)
        merged.left = node1
        merged.right = node2
        heapq.heappush(priority_queue, merged)

    # Generate Huffman codes for each character
    codes = {}
    root = heapq.heappop(priority_queue)
    generate_codes(root, "", codes)

    # Encode the text using the generated codes
    encoded_text = ""
    for char in text:
        encoded_text += codes[char]

    return encoded_text, codes


# Function to decode the encoded text using Huffman codes
def huffman_decoding(encoded_text, codes):
    reversed_codes = {code: char for char, code in codes.items()}

    decoded_text = ""
    current_code = ""
    for bit in encoded_text:
        current_code += bit
        if current_code in reversed_codes:
            char = reversed_codes[current_code]
            decoded_text += char
            current_code = ""

    return decoded_text


# Function to compress a file using Huffman coding
def compress_huffman(file_path):
    # Read the file and get the text content
    with open(file_paths, 'r') as file:
        text = file.read()

    # Compress the text using Huffman coding
    encoded_text, codes = huffman_encoding(text)

    # Write the encoded binary data to a file
    compressed_file_path = file_path + '.huf'
    with open(compressed_file_path, 'wb') as file:
        file.write(bytes(encoded_text, 'utf-8'))

    return compressed_file_path


# LZW compression algorithm implementation
def compress_lzw(file_path):
    # Read the file and get the text content
    with open(file_path, 'r') as file:
        text = file.read()

    # Initialize the dictionary with ASCII characters
    dictionary = {chr(i): i for i in range(256)}
    next_code = 256

    # Compress the text using LZW algorithm
    compressed_text = []
    current_code = ""
    for char in text:
        current_code += char
        if current_code not in dictionary:
            compressed_text.append(dictionary[current_code[:-1]])
            dictionary[current_code] = next_code
            next_code += 1
            current_code = char

    # Add the last code to the compressed text
    compressed_text.append(dictionary[current_code])

    # Convert the compressed text to bytes
    compressed_bytes = bytearray()
    for code in compressed_text:
        compressed_bytes.extend(divmod(code, 256))

    # Write the compressed bytes to a file
    compressed_file_path = file_path + '.lzw'
    with open(compressed_file_path, 'wb') as file:
        file.write(compressed_bytes)

    return compressed_file_path


# Function to calculate the compression ratio
def calculate_compression_ratio(original_file_path, compressed_file_path):
    original_size = os.path.getsize(original_file_path)
    compressed_size = os.path.getsize(compressed_file_path)
    compression_ratio = original_size / compressed_size
    return compression_ratio


# Sample usage
file_paths = ['1260.txt', '1497.txt', '30360.txt']

huffman_ratios = []
lzw_ratios = []

for file_path in file_paths:
    huffman_compressed_file = compress_huffman(file_path)